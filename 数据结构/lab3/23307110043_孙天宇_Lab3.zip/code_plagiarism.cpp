#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;

// 构建KMP算法的next数组
vector<int> buildNext(const string& pattern) {
    int m = pattern.length();
    vector<int> next(m, 0);
    
    int j = 0;
    for (int i = 1; i < m; i++) {
        while (j > 0 && pattern[i] != pattern[j]) {
            j = next[j - 1];
        }
        
        if (pattern[i] == pattern[j]) {
            j++;
        }
        
        next[i] = j;
    }
    
    return next;
}

// 使用KMP算法计算模式串在文本串中的出现次数
int kmpSearch(const string& text, const string& pattern) {
    int n = text.length();
    int m = pattern.length();
    
    if (m > n || m == 0) {
        return 0;
    }
    
    vector<int> next = buildNext(pattern);
    int count = 0;
    int j = 0;
    
    for (int i = 0; i < n; i++) {
        while (j > 0 && text[i] != pattern[j]) {
            j = next[j - 1];
        }
        
        if (text[i] == pattern[j]) {
            j++;
        }
        
        if (j == m) {
            count++;
            j = next[j - 1];
        }
    }
    
    return count;
}

// 检测代码片段T在代码S中的出现次数
// 通过结构模式匹配检测相似性
int countCodeMatches(const string& S, const string& T) {
    int n = S.length();
    int m = T.length();
    
    if (m > n || m == 0) {
        return 0;
    }
    
    int count = 0;
    
    // 尝试所有可能的起始位置
    for (int start = 0; start <= n - m; start++) {
        // 检查从start位置开始的长度为m的子串是否与T匹配
        map<char, char> s2t; // S到T的映射
        map<char, char> t2s; // T到S的映射（反向映射）
        
        bool match = true;
        
        for (int i = 0; i < m; i++) {
            char sChar = S[start + i];
            char tChar = T[i];
            
            bool sIsVar = (sChar >= 'a' && sChar <= 'z');
            bool tIsVar = (tChar >= 'a' && tChar <= 'z');
            
            if (sIsVar && tIsVar) {
                // 都是变量，需要建立双向映射
                if (s2t.find(sChar) == s2t.end() && t2s.find(tChar) == t2s.end()) {
                    s2t[sChar] = tChar;
                    t2s[tChar] = sChar;
                } else if (s2t[sChar] != tChar || t2s[tChar] != sChar) {
                    match = false;
                    break;
                }
            } else if (!sIsVar && !tIsVar) {
                // 都是非变量符号，必须完全相同
                if (sChar != tChar) {
                    match = false;
                    break;
                }
            } else {
                // 一个是变量一个不是，不匹配
                match = false;
                break;
            }
        }
        
        if (match) {
            count++;
        }
    }
    
    return count;
}

int main() {
    string S, T;
    cin >> S >> T;
    
    // 使用代码匹配算法计算T在S中的出现次数
    int result = countCodeMatches(S, T);
    
    cout << result << endl;
    
    return 0;
}
